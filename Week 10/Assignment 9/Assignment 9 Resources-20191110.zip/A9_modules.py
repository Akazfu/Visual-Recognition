import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F


class TrainParams:
    """
    :ivar optim_type: 0: SGD, 1: ADAM

    :ivar load_weights:
        0: train from scratch,
        1: load and test
        2: load if it exists and continue training

    :ivar save_criterion:  when to save a new checkpoint
        0: max validation accuracy
        1: min validation loss,
        2: max training accuracy
        3: min training loss

    :ivar vis: visualize the input and reconstructed images during validation and testing
    """

    def __init__(self):
        self.batch_size = 128
        self.optim_type = 0
        self.lr = 0.001
        self.momentum = 0.9
        self.n_epochs = 1000
        self.weight_decay = 0.0005
        self.c0 = 1
        self.save_criterion = 0
        self.load_weights = 2
        self.weights_path = './checkpoints/model.pt'
        self.vis = 0


class MNISTParams(TrainParams):
    def __init__(self):
        super(MNISTParams, self).__init__()
        self.weights_path = './checkpoints/mnist/model.pt'


class FMNISTParams(TrainParams):
    def __init__(self):
        super(FMNISTParams, self).__init__()
        self.weights_path = './checkpoints/fmnist/model.pt'


class CompositeLoss(nn.Module):
    def __init__(self, device):
        super(CompositeLoss, self).__init__()
        pass

    def init_weights(self):
        pass

    def forward(self, reconstruction_loiss, classification_loss):
        pass


class Encoder(nn.Module):
    def __init__(self, device):
        super(Encoder, self).__init__()
        pass

    def get_weights(self):
        pass

    def init_weights(self):
        pass

    def forward(self, enc_input):
        pass


class Decoder(nn.Module):
    def __init__(self, device):
        super(Decoder, self).__init__()
        pass

    def init_weights(self, shared_weights):
        pass

    def forward(self, dec_input):
        pass


class Classifier(nn.Module):
    def __init__(self, device):
        super(Classifier, self).__init__()
        pass

    def init_weights(self):
        pass

    def forward(self, x):
        pass
